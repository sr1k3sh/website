<template>
  <div id="app">
    
    <div class="container-fluid test fill"  >    
    </div>
    
     <!-- <div class="hello">
        <hello-world/>
      </div> -->
     <vision-icons class="v-icon" @click.native="sible"/>
        <div class="container-fluid fill">
          <vision class="vision" />
        </div> 
  
  </div>
</template>


<script>                            


//import Logo from './components/Logo.vue'
import Vision from './components/VisionComponent.vue'
import VisionIcons from './components/VisionIcons.vue'
import {bounce} from './js/animate';

export default {
  
 
  name: 'app',
  data() {
    return {
     message:'rikesh',
     seen:false,
    
    }
  },
  methods:{
     sible:function(){
       //console.log("rikesh clicking");
       //this.seen=true
       //translate('.vision',-200,0,10,10);
       bounce('.vision');
       
       
     }
  },
  components: {
    VisionIcons,Vision
  }
  
}
</script>

<style>
.vision{
      margin-top:-80px;
      position: relative;
}
.fill{
  float:right;
}
.test{
  background-image: url("assets/background.png");
  filter:blur(21px) saturate(140%) brightness(1);
  background-position: right;
  position: absolute;
    min-height: 100%;
    height:100%;
    min-width: 100%;
    width:100%;
    /* background-repeat: no-repeat center fixed; */
    background-size:cover;
}

#app {
  font-family: 'Avenir', Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  /* margin-top: 60px; */
}


.block {
    pointer-events: none;
    position: relative;
    width: 128px;
    height: 128px;
    margin: 1px;
    background-color: currentColor;
    font-size: 12px;
    color: #2c3e50;
}


</style>
