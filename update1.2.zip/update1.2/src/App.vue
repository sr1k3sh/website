<template>
  <div id="app">
    
    <div class="container-fluid back"  >   
    </div>
     <div class="container-fluid">
          <vision-icons class="v-icon" @click.native="sible"/>
          <Vision class="vision fill" />
        </div> 
     <!-- <div class="hello">
        <hello-world/>
      </div> -->
     
  
  </div>
</template>


<script>                            


//import Logo from './components/Logo.vue'
import Vision from './components/VisionComponent.vue'
import VisionIcons from './components/VisionIcons.vue'
import {bounce} from './js/animate';

export default {
  
 
  name: 'app',
  data() {
    return {
     message:'rikesh',
     seen:false,
    
    }
  },
  methods:{
     sible:function(){
       //console.log("rikesh clicking");
       //this.seen=true
       //translate('.vision',-200,0,10,10);
       bounce('.vision');
       
       
     }
  },
  components: {
    VisionIcons,Vision
  }
  
}
</script>

<style>


.fill{
  float:right;
}
.back{
  background-image: url("assets/background.png");
  
  background-position: right;
  position: fixed;
    min-height: 100%;
    max-height:100%;
    height:100%;
    min-width: 100%;
    width:100%;

    filter:blur(21px) saturate(140%) brightness(1);
    background-repeat: no-repeat center fixed;
    background-size:cover;
}


#app {
  font-family: 'Avenir', Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  /* margin-top: 60px; */
}


.block {
    pointer-events: none;
    position: relative;
    width: 128px;
    height: 128px;
    margin: 1px;
    background-color: currentColor;
    font-size: 12px;
    color: #2c3e50;
}


</style>
