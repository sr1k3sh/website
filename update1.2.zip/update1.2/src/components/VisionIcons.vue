<template>
   <div class="Preloader">
        <div class="loader">
         <svg id="xloader1" height="40px" width="40px" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100" >
            <line  id="cross1" stroke="white" stroke-width="10px" stroke-linecap="round" x1="13.75" y1="83.88" x2="82.22" y2="17.78"/>
            <line  id="cross2" stroke="white" stroke-width="10px" stroke-linecap="round" x1="15.53" y1="16" x2="84" y2="82.11"/>
          </svg>
        </div>
        
        <div class="Welcome" v-if="seen" id="text-transition" @click="Response">
          <!-- <h4 style="color:white;" v-if="Textchange">{{greetings}}</h4> -->
           <textra id="welcome-text" :data='words' :timer="2" filter="simple" :infinite="true"/>
        </div>     
        <div id="box-transition">
          
              <div class="box1"  @click="Response">
                  <img id="image1" v-if="seen" src="@/assets/image1.png">
                  <h4 id="text1" v-if="seen">Individual</h4>
              </div>
          
              <div class="box2" @click="Response" >
                  <h4 id="text2" v-if="seen">Banks and Financial Institutiona</h4>
                  <img id="image2" v-if="seen" src="@/assets/image2.png">
              </div>
         
           
        </div>
        <div class="logo">
              <Logo /> 
        </div>
        <div class="slogan">
              <h1 >Let us Cre<span style="color:white;">ate the future</span></h1>
        </div>
       
        
    </div>
    
</template>
 


<script>
 
 import anime from 'animejs';
 import Logo from '../components/Logo';
 import {translate} from '../js/animate';
 import {cross} from '../js/animate';
 //import { setInterval } from 'timers';
 import {Textra} from 'vue-textra'
 import Vue from 'vue'
var greet="Hello, I'm Vision Assist";
Vue.use(Textra);
export default {
  
 
  data() {
    return {
      seen:true,
      greetings:greet,
       words:["Hello I'm Vision Assist","Which one would be you?"]
     
    };
  },
  methods:{
                Response:function(){
                  function myFunction(x) {
                      if (x.matches) { // If media query matches
                      ///small screen query 
                          translate('.box1',235,132,100);
                          translate('.box2',-127,-186,0,100);
                          translate('.slogan',500,0,1000,500);
                        //// large screen query
                      } else {
                           translate('.box1',222,130,0,100);
                           translate('.box2',-310,-119,0,100);
                           translate('.slogan',750,0,1000,500);
                        }
                      }
                      var x = window.matchMedia("(max-width: 1366px)")
                      myFunction(x) // Call listener function at run time
                      x.addListener(myFunction)
                  
                  
                  ////translate('id/class',translatex,translatey,delay,duration)
                   
                   
                   translate('#xloader1',1000,-400,0,500);
                   this.seen=false;
                    // this.greetings = arg
                    // return this.greetings;
                }
              
  },
  mounted:function() {
       
   var val1=[anime.setDashoffset, -90];
   var val2=[-90,anime.setDashoffset];
       cross('#cross1',val1,1200);
       cross('#cross2',val2,1100);
      function myFunction(x) {
                      if (x.matches) { // If media query matches
                      ///small screen query 
                          translate('.box1',0,('80%'),4100,100);
                          translate('.box2',0,('-150%'),4100,100);
                        //// large screen query
                      } else {
                             translate('.box1',0,('80%'),4100,100);
                              translate('.box2',0,('-95%'),4100,100);
                        }
                      }
                      var x = window.matchMedia("(max-width: 1366px)")
                      myFunction(x) // Call listener function at run time
                      x.addListener(myFunction)
                  
                
      
       //this.Navs();
       
      
  },
  components:{
    Logo
  }
}
 
</script>
<style>
@import '../css/VisionIcons.css';
</style>




