<template>

  
  <div class="VisionAssist" v-on:click="test">
    <div class="assistant">
        <h5 style="color:white;text-align:justify">{{message}}</h5>
        <input id="in" v-if="seen" type="text" value="...or looking for something in particular?">
    </div>
   <!-- -->
    <div class="circle"  @mouseover="changeTitle()" v-on:click="method1()+method2()"  >
  
         <svg id="xloader" height="20px" width="20px" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100" >
            <line  id="cross1" stroke="white" stroke-width="8px" stroke-linecap="round" x1="13.75" y1="83.88" x2="82.22" y2="17.78"/>
            <line  id="cross2" stroke="white" stroke-width="8px" stroke-linecap="round" x1="15.53" y1="16" x2="84" y2="82.11"/>
          </svg>
    </div>
  </div>
</template>

<script>
 import anime from 'animejs';
 import {cross} from '../js/animate';
 

export default {
 name: 'Vision',     
  props:['in'],
  data() {
    
    return {
      seen:false,
      message:'Hey there!',
      text:'...or looking for something in particular?'

    };
  },
  methods:{
                method1:function(){
                    this.message = 'Thinking of your next steps?'
                    return this.message;
                },
                method2:function(){
                  this.seen=true
                },
                changeTitle:function(){
                   //console.log('ok');
                  this.message='Let me know if you need help'
                },
                test:function(){
                  //console.log('ok');
                }
   
  },
  mounted() {
      
   var val1=[anime.setDashoffset, -90];
   var val2=[-90,anime.setDashoffset];
       cross('#cross1',val1,1200);
       cross('#cross2',val2,1100);
       
  }
}

 
</script>
<style>
@import '../css/VisionComponent.css';
</style>

