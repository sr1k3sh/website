<template>
  <div id="app">
    
    <!-- <div class="container-fluid back"  >   
    </div> -->
     <div class="container-fluid ">
        <div class="logo">
              <Logo/> 
        </div>
          <div class="back"/>
         
              <cards class="cards" v-bind:class="[isTrue?'beforeblock':'afterblock']" v-on:click.native="removeVision" />
              <block class="mobileblock" v-bind:class="[isTrue?'beforeblock':'afterblock']"></block>
              <DesktopVision class="vision" v-if="!visible" v-on:click.native="toogle" />
          <div class="slogan">
              <h1 ><span>Let us Cre</span><span style="color:white;">ate the future</span></h1>
          </div>
          <xloader class="xloader" v-if="visible"/>
          <!-- <VisionIcons class="v-icon"/> -->
          
        
      </div> 
     <!-- <div class="hello">
        <hello-world/>
      </div> -->
      
  
  </div>
</template>


<script>                            

import Xloader from './components/Xloader.vue';
//import Logo from './components/Logo.vue'
import DesktopVision from './components/VisionComponent.vue';
import block from './components/block1.vue';

import cards from './components/Cards.vue';
import Logo from './components/Logo';

import {translate,visiblity} from './js/animate';
export default {
  
 
  name: 'app',
  data() {
    return {
     message:'rikesh',
     seen:false,
     visible:true,
     isTrue:true,
    }
  },
  methods:{
     sible:function(){
       //console.log("rikesh clicking");
       this.seen=true
       //translate('.vision',-200,0,10,10);
      //  bounce('.vision');
       
       
     },
     removeVision:function(){
       this.visible=false;
       
       function  myFunction() {
                       
                     
                     if (x.matches) { // If media query matches
                     //desktop screen
                      
                          translate('.slogan','132%',0,1000,500);
                        //// large screen query
                      } 
                      else {
                        ///scaling(target, translatex, translatey, delay, duration,scale){
                     
                            visiblity('.mobileblock',1);
                          // scale('.box1',2);
                           //translate('.slogan',750,0,1000,500);
                        }
                        
                      }
                      var x=window.matchMedia("(min-width: 768px)")
                      myFunction(x) // Call listener function at run time
                      x.addListener(myFunction)
     },
     toogle:function(){
       
                  if(this.isTrue)
                  {

                    this.isTrue=false;
                  }
                  else{
                    
                    this.isTrue=true;
                  }
                },
     mobile:function(){
       this.seen=!this.seen;
     }
  },
  components: {
   DesktopVision,cards,block,Logo,Xloader
  }
  
}
</script>

<style>

.fill{
  float:right;
}
.back{
  background-image: url("assets/background.png");
  
  background-position: right;
  position: fixed;
    min-height: 100%;
    max-height:100%;
    height:100%;
    min-width: 100%;
    width:100%;

    filter:blur(21px) saturate(140%) brightness(1);
    background-repeat: no-repeat center fixed;
    background-size:cover;
}


#app {
  font-family: 'Avenir', Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  /* margin-top: 60px; */
}


.block {
    pointer-events: none;
    position: relative;
    width: 128px;
    height: 128px;
    margin: 1px;
    background-color: currentColor;
    font-size: 12px;
    color: #2c3e50;
}
.container-fluid{
  position: relative;
  overflow: hidden;
  height:100vh;
}
.v-icon{
  display:block;
}

.xloader1{
  visibility: hidden;
}
.xloader2{
  visibility: visible;
}
@media only screen and (max-width: 768px) {
.beforeblock{
  visibility: visible;
}
.afterblock{
  visibility:hidden;
}
}
@import './css/VisionIcons.css';
</style>
